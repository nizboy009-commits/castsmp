CastSMP 26.2 custom item-model pack

This is an independently created compatibility pack with original simple icons. It does NOT contain the official Modrinth Cast SMP Resource Pack, whose license is ARR. To use this pack, zip the contents of this folder so pack.mcmeta is at the ZIP root. This pack's format value is a provisional setting and must be checked in Minecraft Java 26.2 before use; if Minecraft reports a pack-format warning, update pack.mcmeta for the exact client build.
